const app = require('../server');

module.exports = (req, res) => {
    // If Vercel rewrote destination to /api/index.js, restore requested URI
    if (req.url === '/api/index.js' || req.url === '/api/index' || req.url === '/api') {
        const originalUri = req.headers['x-forwarded-uri'] || req.originalUrl;
        if (originalUri && originalUri.startsWith('/api')) {
            req.url = originalUri;
        }
    }

    // Ensure req.url starts with /api for Express routing
    if (req.url && !req.url.startsWith('/api')) {
        req.url = '/api' + (req.url.startsWith('/') ? req.url : '/' + req.url);
    }

    return app(req, res);
};


